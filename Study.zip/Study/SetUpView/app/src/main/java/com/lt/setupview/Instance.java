package com.lt.setupview;

public class Instance {
    private static Instance instance;
    public static Instance getInstance(){
        if (instance==null){
            instance=new Instance();
        }
        return instance;
    }

    public void getSomeThing(){
        synchronized (getInstance()){
        }
    }
}
