package com.lt.setupview;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class baseDialog extends Dialog {
    public baseDialog(@NonNull Context context) {
        super(context);
    }

    public baseDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    protected baseDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }
}
