package com.lt.setupview.SearchLaodingView;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.lt.setupview.R;

public class SearchActivity extends AppCompatActivity {
    SearchToLoadingView searchToLoadingView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        searchToLoadingView=findViewById(R.id.search);
        searchToLoadingView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchToLoadingView.start();
            }
        });
    }
}
