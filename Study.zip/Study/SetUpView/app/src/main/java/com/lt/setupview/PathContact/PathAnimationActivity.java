package com.lt.setupview.PathContact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.lt.setupview.R;

public class PathAnimationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_path_animation);
    }
}
