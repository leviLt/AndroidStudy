package com.lt.setupview;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.lt.setupview.PathContact.PathAnimationActivity;
import com.lt.setupview.SearchLaodingView.SearchActivity;
import com.lt.setupview.SearchLaodingView.SearchToLoadingView;

import java.io.File;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    Button editText;
    Dialog dialog;
    ZpPhoneEditText editTextPhone;
    Button btnPhone;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.dialog);
        editTextPhone = findViewById(R.id.phone);
        btnPhone = findViewById(R.id.btn_phone);
        editText.setOnClickListener(this);
        dialog = new Dialog(this);
        dialog.setOwnerActivity(this);
        showImgType();


        btnPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnPhone.setText(editTextPhone.getPhoneText());
            }
        });
    }

    private void showImgType() {
        Glide.with(this)
                .downloadOnly()
                .load(R.drawable.search)
                .into(new SimpleTarget<File>() {
                    @Override
                    public void onResourceReady(@NonNull File resource, @Nullable Transition<? super File> transition) {
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inJustDecodeBounds = false;
                        BitmapFactory.decodeFile(resource.getPath(), options);
                        Log.e(TAG, "img type========= " + options.outMimeType);
                    }
                });
    }

    @Override
    public void onClick(View v) {
//        View view = LayoutInflater.from(this).inflate(R.layout.dialog_layout, null);
//        dialog.setContentView(view);
//        dialog.setCancelable(false);
//        dialog.show();
//        view.findViewById(R.id.close).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//               InputMethodManager inputMethodManager= (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//               inputMethodManager.hideSoftInputFromWindow(dialog.getWindow().getDecorView().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
//            }
//        });
        switch (v.getId()) {
            case R.id.dialog:
                Intent intent = new Intent(this, PathAnimationActivity.class);
                startActivity(intent);
                break;
            case R.id.search:
                Intent intent1 = new Intent(this, SearchActivity.class);
                startActivity(intent1);
                break;
        }

    }
}
