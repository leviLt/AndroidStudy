package com.lt.setupview.SearchLaodingView;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;


public class SearchToLoadingView extends View {
    private static final String TAG = "SearchToLoadingView";
    Paint paint;
    int width, height;

    public static enum State {
        NONE,
        STARTING,
        SEARCHING,
        ENDING
    }

    //当前状态
    private State currentState = State.NONE;
    //大圆圈的path
    private Path loadingPath;
    //搜索Path
    private Path searchPath;

    //path 测量工具
    private PathMeasure pathMeasure;
    //控制各个动画的值
    private ValueAnimator mStartingAnimayor, mSearchingAnimator, mEndinghAnimator;
    //默认的动画时长 ms
    private int defaulfDuration = 2000;
    //动画监听
    private ValueAnimator.AnimatorListener animatorListener;
    private ValueAnimator.AnimatorUpdateListener updateListener;
    //动画的值  也就是ValueAnimator的进度值  初始值为0
    private float mAnimatorValue = 0;
    //handle 控制动画的切换
    private Handler mAnimatorHandle;
    //判断搜索是否结束
    private boolean isOver = false;
    //结束动画标志
    private int count;

    public SearchToLoadingView(Context context) {
        this(context, null);
    }

    public SearchToLoadingView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SearchToLoadingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        //sdk版本消息KITKAT 要关闭硬件加速 否则PathMeasure无法画到canvas上
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }
        init();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightSize = MeasureSpec.getSize(widthMeasureSpec);
        //因为要绘制成正方形
        //1。先判断以那条边为标准
        //2。再判断 给的宽度是MathParent（AT_MOST） WrapContent（UNSPECIFIED） 还是精确值（EXACTLY）
        if (widthSize <= heightSize) {
            switch (widthMode) {
                case MeasureSpec.AT_MOST:
                    height = widthSize;
                    width = widthSize;
                    break;
                case MeasureSpec.EXACTLY:
                    width = widthSize;
                    height = widthSize;
                    break;
                case MeasureSpec.UNSPECIFIED:
                    width = 100;
                    height = 100;
                    break;
            }
        } else {
            if (heightMode != MeasureSpec.UNSPECIFIED) {
                width = height = heightSize;
            } else {
                width = height = 100;
            }
        }
        setMeasuredDimension(width, height);
    }

    private void init() {
        //画笔初始化
        initPaint();
        //initPath
        initPath();
        //init Listener
        initListener();
        //init animator
        initAnimator();
        //init  handle
        initHandle();
        // 进入开始动画
        currentState = State.NONE;
        mStartingAnimayor.start();
    }


    private void initPaint() {
        paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setDither(true);
        paint.setAntiAlias(true);
        paint.setStrokeWidth(10);
        paint.setColor(Color.WHITE);
//        width = (int) (width + paint.getStrokeWidth());
//        height = (int) (height + paint.getStrokeWidth());
    }

    private void initPath() {
        loadingPath = new Path();
        searchPath = new Path();
        pathMeasure = new PathMeasure();

        //放大镜圆环
        RectF smallOval = new RectF(-50, -50, 50, 50);
        //这里踩一个坑  直接sweepAngle如果写360的话，不能截取到Path
        searchPath.addArc(smallOval, 45, 359.9f);
        //loading 圆环
        RectF largeOval = new RectF(-100, -100, 100, 100);
        loadingPath.addArc(largeOval, 45, 359.f);

        pathMeasure.setPath(loadingPath, true);
        //放大镜把手位置
        float[] pos = new float[2];
        pathMeasure.getPosTan(0, pos, null);
        searchPath.lineTo(pos[0], pos[1]);

        Log.e(TAG, "posX============: " + pos[0] + ":" + "posY==============" + pos[1]);
    }


    private void initListener() {

        animatorListener = new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mAnimatorHandle.sendEmptyMessage(0);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        };
        updateListener = new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                mAnimatorValue = (float) animation.getAnimatedValue();
                invalidate();
            }
        };

    }

    private void initAnimator() {
        mStartingAnimayor = ValueAnimator.ofFloat(0, 1).setDuration(defaulfDuration);
        mSearchingAnimator = ValueAnimator.ofFloat(0, 1).setDuration(defaulfDuration);
        mEndinghAnimator = ValueAnimator.ofFloat(1, 0).setDuration(defaulfDuration);

        mStartingAnimayor.addListener(animatorListener);
        mSearchingAnimator.addListener(animatorListener);
        mEndinghAnimator.addListener(animatorListener);

        mStartingAnimayor.addUpdateListener(updateListener);
        mSearchingAnimator.addUpdateListener(updateListener);
        mEndinghAnimator.addUpdateListener(updateListener);
    }


    @SuppressLint("HandlerLeak")
    private void initHandle() {
        mAnimatorHandle = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (currentState) {
                    case STARTING:
                        isOver = false;
                        currentState = State.SEARCHING;
                        mSearchingAnimator.start();
                        break;
                    case SEARCHING:
                        //搜索未结束则继续搜索
                        if (!isOver) {
                            mSearchingAnimator.start();
                            Log.e(TAG, "loading search restart");
                            count++;
                            if (count >= 2) {
                                //超过2次就结束动画
                                isOver = true;
                            }
                        } else {
                            currentState = State.ENDING;
                            mEndinghAnimator.start();
                        }
                        break;
                    case ENDING:
                        //无状态
                        currentState = State.NONE;
                        break;
                }
            }
        };
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //移动画布到中心
        canvas.translate(width / 2, height / 2);
        //背景蓝色
        canvas.drawColor(Color.parseColor("#0082D7"));

        switch (currentState) {
            case NONE:
                //绘制搜索
                canvas.drawPath(searchPath, paint);
                break;
            case STARTING:
                pathMeasure.setPath(searchPath, false);
                Path startDst = new Path();
                pathMeasure.getSegment(pathMeasure.getLength() * mAnimatorValue, pathMeasure.getLength(), startDst, true);
                canvas.drawPath(startDst, paint);
                break;
            case SEARCHING:
                pathMeasure.setPath(loadingPath, false);
                Path loadIngPath = new Path();
                float stop = pathMeasure.getLength() * mAnimatorValue;
                float start= (float) (stop - ((0.5 - Math.abs(mAnimatorValue - 0.5)) * 200f));
                pathMeasure.getSegment(start,stop,loadIngPath,true);
                canvas.drawPath(loadIngPath,paint);
                break;
            case ENDING:
                pathMeasure.setPath(searchPath,false);
                Path endingpath=new Path();
                pathMeasure.getSegment(pathMeasure.getLength()*mAnimatorValue,pathMeasure.getLength(),endingpath,true);
                canvas.drawPath(endingpath,paint);
                break;
        }
    }
    public void start(){
        currentState=State.STARTING;
        mStartingAnimayor.start();
        count=0;
        invalidate();
    }
}
