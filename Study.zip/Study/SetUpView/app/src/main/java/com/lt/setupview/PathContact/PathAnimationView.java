package com.lt.setupview.PathContact;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.arch.lifecycle.ViewModelProvider;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;


public class PathAnimationView extends View implements ValueAnimator.AnimatorUpdateListener, ValueAnimator.AnimatorListener {
    private static final String TAG = "PathAnimationView";
    int width = 200;
    int height = 200;
    int centerX;
    int centerY;
    Path path;
    PathMeasure pathMeasure;
    Paint paint;
    ValueAnimator animator;
    float currentValues = 0;

    public PathAnimationView(Context context) {
        super(context);
    }

    public PathAnimationView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        if (Build.VERSION.SDK_INT<=21){
            setLayerType(LAYER_TYPE_SOFTWARE,null);
        }
        init();
    }


    public PathAnimationView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2;
        centerY = h / 2;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(dp2px(getContext(), width), dp2px(getContext(), height));
        centerX = getWidth() / 2;
        centerY = getHeight() / 2;
    }

    private int dp2px(Context context, int px) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return (int) (px * metrics.density + 0.5f);
    }

    private void init() {
        path = new Path();
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(10);
        //初始化动画
        animator = ValueAnimator.ofFloat(0, 1).setDuration(2000);
        animator.addUpdateListener(this);
        animator.addListener(this);
        pathMeasure = new PathMeasure();
        animator.start();
    }


    @Override
    protected void onDraw(Canvas canvas) {
//        RectF rectF=new RectF(paint.getStrokeWidth()/2,paint.getStrokeWidth()/2,getWidth()-paint.getStrokeWidth()/2,getHeight()-paint.getStrokeWidth()/2);
//        path.addArc(rectF, 0,360);
        path.addCircle(centerX,centerY,getWidth()/2-paint.getStrokeWidth()/2, Path.Direction.CW);
        pathMeasure.setPath(path, true);
        Path p = new Path();
        Log.e(TAG, "onDraw-> pathMeasure.getLength()=========="+pathMeasure.getLength()*currentValues);
        Log.e(TAG, "getWidth()/2=========="+getWidth()/2);
        Log.e(TAG, "getHeight()/2=========="+getHeight()/2);
        pathMeasure.getSegment(0, pathMeasure.getLength() * currentValues, p, true);
        canvas.drawPath(p, paint);
    }

    @Override
    public void onAnimationStart(Animator animation) {

    }

    @Override
    public void onAnimationEnd(Animator animation) {

    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }

    @Override
    public void onAnimationUpdate(ValueAnimator animation) {
        //获取进度值
        currentValues = (float) animation.getAnimatedValue();
        //刷新
        invalidate();
    }
}
